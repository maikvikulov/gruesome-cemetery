import { createServer } from 'node:http';
import { DatabaseSync } from 'node:sqlite';
import { randomBytes, createHash, scrypt, timingSafeEqual } from 'node:crypto';
import { promisify } from 'node:util';
import { mkdirSync, statSync, realpathSync, createReadStream } from 'node:fs';
import { dirname, extname, resolve, sep } from 'node:path';
import { fileURLToPath } from 'node:url';

const deriveKey = promisify(scrypt);
const projectRoot = resolve(dirname(fileURLToPath(import.meta.url)), '..');
const categories = new Set(['javascript', 'python', 'web', 'career', 'tools']);
const sessionLifetime = 7 * 24 * 60 * 60 * 1000;
const cookieName = 'codelife_session';

class HttpError extends Error {
  constructor(status, message) {
    super(message);
    this.status = status;
  }
}

function fail(status, message) {
  throw new HttpError(status, message);
}

function text(value, min, max, label) {
  if (typeof value !== 'string') fail(400, `Заполни поле «${label}».`);
  const result = value.trim();
  if (result.length < min || result.length > max) {
    fail(400, `Поле «${label}»: от ${min} до ${max} символов.`);
  }
  return result;
}

function credentials(body) {
  const username = text(body.username, 3, 24, 'Имя пользователя');
  if (!/^[\p{L}\p{N}_-]+$/u.test(username)) {
    fail(400, 'В имени можно использовать буквы, цифры, дефис и подчёркивание.');
  }
  if (typeof body.password !== 'string' || body.password.length < 8 || body.password.length > 128) {
    fail(400, 'Пароль должен содержать от 8 до 128 символов.');
  }
  return { username, password: body.password };
}

async function passwordHash(password) {
  const salt = randomBytes(16).toString('hex');
  const key = await deriveKey(password, salt, 64);
  return `scrypt:${salt}:${key.toString('hex')}`;
}

async function verifyPassword(password, hash) {
  const [scheme, salt, expected] = hash.split(':');
  // A fixed dummy calculation also keeps nonexistent/disabled users on the same path.
  const key = await deriveKey(password, scheme === 'scrypt' ? salt : 'codelife-dummy-salt', 64);
  if (scheme !== 'scrypt' || !/^[a-f0-9]{128}$/.test(expected || '')) return false;
  return timingSafeEqual(key, Buffer.from(expected, 'hex'));
}

function tokenDigest(token) {
  return createHash('sha256').update(token).digest('hex');
}

function sendJson(response, status, body) {
  response.writeHead(status, { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store' });
  response.end(JSON.stringify(body));
}

async function readBody(request) {
  if (!/^application\/json(?:\s*;|$)/i.test(request.headers['content-type'] || '')) {
    fail(415, 'Отправь данные в формате JSON.');
  }
  let length = 0;
  const chunks = [];
  for await (const chunk of request) {
    length += chunk.length;
    if (length > 32 * 1024) fail(413, 'Слишком много данных в одном запросе.');
    chunks.push(chunk);
  }
  try {
    const body = JSON.parse(Buffer.concat(chunks).toString('utf8'));
    if (!body || typeof body !== 'object' || Array.isArray(body)) fail(400, 'Нужен JSON-объект.');
    return body;
  } catch (error) {
    if (error instanceof HttpError) throw error;
    fail(400, 'Не удалось разобрать JSON.');
  }
}

function initializeDatabase(db, seed) {
  // SQLite's built-in LOWER/LIKE only fold ASCII. Match Russian headings too.
  db.function('unicode_lower', { deterministic: true }, value =>
    typeof value === 'string' ? value.toLocaleLowerCase('ru-RU') : '');
  db.exec(`
    PRAGMA foreign_keys = ON;
    PRAGMA journal_mode = WAL;
    CREATE TABLE IF NOT EXISTS users (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      username TEXT NOT NULL,
      username_key TEXT NOT NULL UNIQUE,
      password_hash TEXT NOT NULL,
      created_at TEXT NOT NULL
    );
    CREATE TABLE IF NOT EXISTS sessions (
      token_hash TEXT PRIMARY KEY,
      user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      expires_at INTEGER NOT NULL
    );
    CREATE TABLE IF NOT EXISTS topics (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      title TEXT NOT NULL,
      content TEXT NOT NULL,
      category TEXT NOT NULL,
      creator_id INTEGER NOT NULL REFERENCES users(id),
      created_at TEXT NOT NULL
    );
    CREATE TABLE IF NOT EXISTS posts (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      topic_id INTEGER NOT NULL REFERENCES topics(id) ON DELETE CASCADE,
      user_id INTEGER NOT NULL REFERENCES users(id),
      content TEXT NOT NULL,
      created_at TEXT NOT NULL
    );
    CREATE TABLE IF NOT EXISTS contacts (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT NOT NULL,
      email TEXT NOT NULL,
      message TEXT NOT NULL,
      created_at TEXT NOT NULL
    );
    CREATE INDEX IF NOT EXISTS posts_by_topic ON posts(topic_id);
    CREATE INDEX IF NOT EXISTS sessions_by_expiry ON sessions(expires_at);
  `);
  if (!seed || db.prepare('SELECT COUNT(*) AS count FROM topics').get().count) return;
  const now = Date.now();
  const examples = [
    ['Почему мой useEffect срабатывает дважды?', 'Разбираюсь с React: в режиме разработки эффект запускается два раза. Это Strict Mode или я опять что-то сломал? Давайте разберём, как правильно чистить эффекты.', 'javascript', 'Здесь дело в Strict Mode: в dev React проверяет корректность очистки эффекта. Верни функцию cleanup и проверь, что подписки удаляются.'],
    ['Python или JavaScript: с чего, блин, начать?', 'Хочу войти в разработку, но уже утонул в советах. Интересны и сайты, и автоматизация рутины. Кто с чего начинал и какой небольшой проект реально помог?', 'python', 'Для сайтов начни с HTML, CSS и JavaScript. Для скриптов и автоматизации попробуй Python. Небольшой законченный проект полезнее бесконечного выбора языка.'],
    ['CSS Grid наконец-то щёлкнул. Делюсь шпаргалкой', 'Долгое время собирал всё на flex, пока не понадобилась сетка карточек. repeat(auto-fit, minmax(240px, 1fr)) решил задачу без пачки медиазапросов. Какие ещё любимые приёмы?', 'web', 'Для переполнения полезно minmax(0, 1fr), а для одинаковых строк — grid-auto-rows: 1fr.'],
    ['Что показать в портфолио, если опыта — ноль?', 'Учебные проекты готовы, но они похожи на сотни других. Думаю собрать полезный инструмент для своего сообщества. Как вы выбирали первый проект для портфолио?', 'career', 'Выбери реальную небольшую проблему и доведи решение до запуска: README, понятный интерфейс и несколько проверок важнее количества фреймворков.'],
    ['Твой терминал выглядит круче моего. Что внутри?', 'Собираю удобное рабочее окружение без сорока плагинов, которые никто не понимает. Покажите свои любимые CLI-инструменты и расскажите, какую задачу они решают.', 'tools', 'ripgrep для поиска, fzf для выбора файлов и обычный git — уже отличная база. Остальное добавляй под конкретную задачу.'],
    ['async/await: почему try/catch не ловит ошибку?', 'Вызвал асинхронную функцию внутри try, а ошибка улетела мимо catch. Выяснилось, что забыл await. Оставляю тему для тех, кто тоже наступит на эту чёртову граблю.', 'javascript', null],
  ];
  db.exec('BEGIN');
  try {
    db.prepare('INSERT OR IGNORE INTO users (username, username_key, password_hash, created_at) VALUES (?, ?, ?, ?)')
      .run('CodeLife', 'codelife', 'disabled', new Date(now).toISOString());
    const user = db.prepare('SELECT id FROM users WHERE username_key = ?').get('codelife');
    const insertTopic = db.prepare('INSERT INTO topics (title, content, category, creator_id, created_at) VALUES (?, ?, ?, ?, ?)');
    const insertPost = db.prepare('INSERT INTO posts (topic_id, user_id, content, created_at) VALUES (?, ?, ?, ?)');
    examples.forEach(([title, content, category, reply], index) => {
      const createdAt = new Date(now - (index + 1) * 3_600_000).toISOString();
      const result = insertTopic.run(title, content, category, user.id, createdAt);
      if (reply) insertPost.run(result.lastInsertRowid, user.id, reply, new Date(now - index * 1_800_000).toISOString());
    });
    db.exec('COMMIT');
  } catch (error) {
    db.exec('ROLLBACK');
    throw error;
  }
}

/**
 * No external services/dependencies. Node 24+ supplies SQLite.
 * createApp({dbPath: ':memory:'}) supports isolated tests; call server.listen()
 * explicitly and await close() to release the HTTP listener and database.
 */
export function createApp({
  dbPath = resolve(projectRoot, 'data', 'codelife.db'),
  clientDir = resolve(projectRoot, 'client'),
  seed = true,
  secureCookies = false,
} = {}) {
  if (dbPath !== ':memory:') mkdirSync(dirname(resolve(dbPath)), { recursive: true });
  const db = new DatabaseSync(dbPath);
  initializeDatabase(db, seed);
  const clientRoot = resolve(clientDir);
  const rateLimits = new Map();
  const topicSelect = `SELECT t.id, t.title, t.content, t.category, u.username, t.created_at,
    (SELECT COUNT(*) FROM posts p WHERE p.topic_id = t.id) AS replies
    FROM topics t JOIN users u ON u.id = t.creator_id`;

  function rateLimit(request, key, limit, period) {
    const now = Date.now();
    const address = request.socket.remoteAddress || 'unknown';
    const entryKey = `${key}:${address}`;
    let entry = rateLimits.get(entryKey);
    if (!entry || entry.until <= now) {
      entry = { count: 0, until: now + period };
      rateLimits.set(entryKey, entry);
    }
    entry.count += 1;
    if (rateLimits.size > 1000) {
      for (const [storedKey, stored] of rateLimits) if (stored.until <= now) rateLimits.delete(storedKey);
    }
    if (entry.count > limit) fail(429, 'Слишком много запросов. Сделай небольшой перерыв.');
  }

  function sessionToken(request) {
    const cookies = (request.headers.cookie || '').split(';');
    for (const cookie of cookies) {
      const [name, ...parts] = cookie.trim().split('=');
      if (name === cookieName) {
        const value = parts.join('=');
        return /^[a-f0-9]{64}$/.test(value) ? value : null;
      }
    }
    return null;
  }

  function currentUser(request) {
    const token = sessionToken(request);
    if (!token) return null;
    const user = db.prepare(`SELECT u.id, u.username FROM sessions s
      JOIN users u ON s.user_id = u.id WHERE s.token_hash = ? AND s.expires_at > ?`)
      .get(tokenDigest(token), Date.now());
    return user || null;
  }

  function requireUser(request) {
    const user = currentUser(request);
    if (!user) fail(401, 'Сначала войди в аккаунт.');
    return user;
  }

  function startSession(request, response, userId) {
    const previous = sessionToken(request);
    if (previous) db.prepare('DELETE FROM sessions WHERE token_hash = ?').run(tokenDigest(previous));
    db.prepare('DELETE FROM sessions WHERE expires_at <= ?').run(Date.now());
    const token = randomBytes(32).toString('hex');
    db.prepare('INSERT INTO sessions (token_hash, user_id, expires_at) VALUES (?, ?, ?)')
      .run(tokenDigest(token), userId, Date.now() + sessionLifetime);
    response.setHeader('Set-Cookie', `${cookieName}=${token}; HttpOnly; SameSite=Lax; Path=/; Max-Age=${sessionLifetime / 1000}${secureCookies ? '; Secure' : ''}`);
  }

  async function handleApi(request, response, url) {
    const route = url.pathname;
    const method = request.method;
    if (!['GET', 'POST'].includes(method)) fail(405, 'Метод не поддерживается.');
    if (method === 'POST' && request.headers.origin) {
      let origin;
      try { origin = new URL(request.headers.origin); } catch { fail(403, 'Недопустимый источник запроса.'); }
      if (origin.host !== request.headers.host) fail(403, 'Недопустимый источник запроса.');
    }

    if (route === '/api/session' && method === 'GET') {
      return sendJson(response, 200, { user: currentUser(request) });
    }
    if (route === '/api/register' && method === 'POST') {
      rateLimit(request, 'register', 20, 3_600_000);
      const { username, password } = credentials(await readBody(request));
      const key = username.normalize('NFKC').toLowerCase();
      if (db.prepare('SELECT id FROM users WHERE username_key = ?').get(key)) {
        fail(409, 'Такое имя уже занято. Придумай другое.');
      }
      const hash = await passwordHash(password);
      let result;
      try {
        result = db.prepare('INSERT INTO users (username, username_key, password_hash, created_at) VALUES (?, ?, ?, ?)')
          .run(username, key, hash, new Date().toISOString());
      } catch (error) {
        if (error.code?.includes('CONSTRAINT') || error.message?.includes('UNIQUE')) fail(409, 'Такое имя уже занято. Придумай другое.');
        throw error;
      }
      const user = { id: Number(result.lastInsertRowid), username };
      startSession(request, response, user.id);
      return sendJson(response, 201, { user });
    }
    if (route === '/api/login' && method === 'POST') {
      rateLimit(request, 'login', 30, 15 * 60_000);
      const { username, password } = credentials(await readBody(request));
      const user = db.prepare('SELECT id, username, password_hash FROM users WHERE username_key = ?')
        .get(username.normalize('NFKC').toLowerCase());
      if (!await verifyPassword(password, user?.password_hash || 'disabled')) {
        fail(401, 'Неверное имя пользователя или пароль.');
      }
      startSession(request, response, user.id);
      return sendJson(response, 200, { user: { id: user.id, username: user.username } });
    }
    if (route === '/api/logout' && method === 'POST') {
      const token = sessionToken(request);
      if (token) db.prepare('DELETE FROM sessions WHERE token_hash = ?').run(tokenDigest(token));
      response.setHeader('Set-Cookie', `${cookieName}=; HttpOnly; SameSite=Lax; Path=/; Max-Age=0${secureCookies ? '; Secure' : ''}`);
      return sendJson(response, 200, { success: true });
    }
    if (route === '/api/topics' && method === 'GET') {
      const category = url.searchParams.get('category');
      const query = (url.searchParams.get('q') || '').trim();
      if (query.length > 160) fail(400, 'Поисковый запрос слишком длинный.');
      if (category && category !== 'all' && !categories.has(category)) fail(400, 'Неизвестная категория.');
      const conditions = [];
      const values = [];
      if (category && category !== 'all') { conditions.push('t.category = ?'); values.push(category); }
      if (query) {
        conditions.push('(unicode_lower(t.title) LIKE ? ESCAPE \'\\\' OR unicode_lower(t.content) LIKE ? ESCAPE \'\\\')');
        const pattern = `%${query.toLocaleLowerCase('ru-RU').replace(/[\\%_]/g, '\\$&')}%`;
        values.push(pattern, pattern);
      }
      const topics = db.prepare(`${topicSelect}${conditions.length ? ` WHERE ${conditions.join(' AND ')}` : ''} ORDER BY t.created_at DESC, t.id DESC LIMIT 100`).all(...values);
      return sendJson(response, 200, { topics });
    }
    if (route === '/api/topics' && method === 'POST') {
      const user = requireUser(request);
      rateLimit(request, 'topics', 15, 60_000);
      const body = await readBody(request);
      const title = text(body.title, 5, 160, 'Заголовок');
      const content = text(body.content, 10, 10000, 'Текст темы');
      if (!categories.has(body.category)) fail(400, 'Выбери категорию темы.');
      const result = db.prepare('INSERT INTO topics (title, content, category, creator_id, created_at) VALUES (?, ?, ?, ?, ?)')
        .run(title, content, body.category, user.id, new Date().toISOString());
      const topic = db.prepare(`${topicSelect} WHERE t.id = ?`).get(result.lastInsertRowid);
      return sendJson(response, 201, { topic });
    }
    const topicRoute = route.match(/^\/api\/topics\/([1-9]\d*)(\/posts)?$/);
    if (topicRoute) {
      const topic = db.prepare(`${topicSelect} WHERE t.id = ?`).get(topicRoute[1]);
      if (!topic) fail(404, 'Тема не найдена.');
      if (method === 'GET' && !topicRoute[2]) {
        const posts = db.prepare(`SELECT p.id, u.username, p.content, p.created_at FROM posts p
          JOIN users u ON u.id = p.user_id WHERE p.topic_id = ? ORDER BY p.id`).all(topic.id);
        return sendJson(response, 200, { topic, posts });
      }
      if (method === 'POST' && topicRoute[2]) {
        const user = requireUser(request);
        rateLimit(request, 'posts', 40, 60_000);
        const body = await readBody(request);
        const content = text(body.content, 2, 5000, 'Ответ');
        const result = db.prepare('INSERT INTO posts (topic_id, user_id, content, created_at) VALUES (?, ?, ?, ?)')
          .run(topic.id, user.id, content, new Date().toISOString());
        const post = db.prepare(`SELECT p.id, u.username, p.content, p.created_at FROM posts p
          JOIN users u ON u.id = p.user_id WHERE p.id = ?`).get(result.lastInsertRowid);
        return sendJson(response, 201, { post });
      }
      fail(405, 'Метод не поддерживается.');
    }
    if (route === '/api/contact' && method === 'POST') {
      rateLimit(request, 'contact', 10, 3_600_000);
      const body = await readBody(request);
      const name = text(body.name, 2, 80, 'Имя');
      const email = text(body.email, 3, 254, 'Email');
      const message = text(body.message, 10, 5000, 'Сообщение');
      if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) fail(400, 'Проверь адрес электронной почты.');
      db.prepare('INSERT INTO contacts (name, email, message, created_at) VALUES (?, ?, ?, ?)')
        .run(name, email, message, new Date().toISOString());
      return sendJson(response, 201, { success: true, message: 'Сообщение сохранено. Спасибо, что написал!' });
    }
    fail(404, 'Такого API здесь нет.');
  }

  function handleStatic(request, response, url) {
    if (!['GET', 'HEAD'].includes(request.method)) fail(405, 'Метод не поддерживается.');
    let pathname;
    try { pathname = decodeURIComponent(url.pathname); } catch { fail(400, 'Некорректный адрес.'); }
    if (pathname.includes('\0') || pathname.includes('\\') || pathname.split('/').some(part => part.startsWith('.'))) {
      fail(404, 'Страница не найдена.');
    }
    const spaRoutes = /^(?:\/(?:index\.html)?|\/(?:about|features|blog|contact)(?:\.html)?\/?|\/(?:login|register|register-user)\/?|\/user\/(?:login|register)\.html|\/forum(?:\/index\.html|\/[1-9]\d*)?\/?|\/article\/[a-z0-9-]+\/?|\/topic_detail\/[1-9]\d*)$/;
    const file = resolve(clientRoot, spaRoutes.test(pathname) ? 'index.html' : `.${pathname}`);
    if (!file.startsWith(`${clientRoot}${sep}`)) fail(404, 'Страница не найдена.');
    let stats;
    try {
      if (!realpathSync(file).startsWith(`${realpathSync(clientRoot)}${sep}`)) fail(404, 'Страница не найдена.');
      stats = statSync(file);
    } catch (error) {
      if (error instanceof HttpError) throw error;
      fail(404, 'Страница не найдена.');
    }
    if (!stats.isFile()) fail(404, 'Страница не найдена.');
    const types = {
      '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8',
      '.css': 'text/css; charset=utf-8', '.svg': 'image/svg+xml', '.png': 'image/png',
      '.jpg': 'image/jpeg', '.webp': 'image/webp', '.ico': 'image/x-icon',
      '.woff2': 'font/woff2', '.json': 'application/json; charset=utf-8',
    };
    const type = types[extname(file)];
    if (!type) fail(404, 'Страница не найдена.');
    response.writeHead(200, { 'Content-Type': type, 'Content-Length': stats.size, 'Cache-Control': 'no-cache' });
    if (request.method === 'HEAD') return response.end();
    const stream = createReadStream(file);
    stream.on('error', () => response.destroy());
    stream.pipe(response);
  }

  const server = createServer(async (request, response) => {
    response.setHeader('X-Content-Type-Options', 'nosniff');
    response.setHeader('Referrer-Policy', 'same-origin');
    response.setHeader('X-Frame-Options', 'SAMEORIGIN');
    try {
      const url = new URL(request.url, 'http://codelife.local');
      if (url.pathname.startsWith('/api/')) await handleApi(request, response, url);
      else handleStatic(request, response, url);
    } catch (error) {
      if (response.headersSent) return response.destroy();
      if (!(error instanceof HttpError)) console.error('Request failed:', error);
      const message = error instanceof HttpError ? error.message : 'Что-то сломалось на сервере. Попробуй ещё раз.';
      sendJson(response, error instanceof HttpError ? error.status : 500, { error: message, message });
    }
  });
  server.requestTimeout = 30_000;
  server.headersTimeout = 15_000;
  let closed = false;
  return {
    server,
    db,
    async close() {
      if (closed) return;
      closed = true;
      if (server.listening) await new Promise((resolveClose, reject) => server.close(error => error ? reject(error) : resolveClose()));
      db.close();
    },
  };
}

if (process.argv[1] && resolve(process.argv[1]) === fileURLToPath(import.meta.url)) {
  const port = Number(process.env.PORT || 3000);
  if (!Number.isInteger(port) || port < 1 || port > 65535) throw new Error('PORT must be between 1 and 65535.');
  const app = createApp({
    dbPath: process.env.DATABASE_PATH || resolve(projectRoot, 'data', 'codelife.db'),
    secureCookies: process.env.SECURE_COOKIES === 'true',
  });
  app.server.listen(port, process.env.HOST || '0.0.0.0', () => console.log(`CodeLife listening on port ${port}`));
  app.server.on('error', error => { console.error(error.message); process.exitCode = 1; app.close(); });
  for (const signal of ['SIGINT', 'SIGTERM']) process.once(signal, async () => { await app.close(); process.exit(0); });
}
