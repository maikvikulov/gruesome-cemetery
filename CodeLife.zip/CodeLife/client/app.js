import { articles, tracks } from './content.js';

const $ = (selector, parent = document) => parent.querySelector(selector);
const escape = value => String(value ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const labels = {javascript:'JavaScript',python:'Python',web:'Веб',career:'Карьера',tools:'Инструменты'};
const icons = {
  search:'<circle cx="10.5" cy="10.5" r="6.5"/><path d="m16 16 4 4"/>',
  moon:'<path d="M20 14.5A8.5 8.5 0 0 1 9.5 4 8.5 8.5 0 1 0 20 14.5Z"/>',
  menu:'<path d="M4 7h16M4 12h16M4 17h16"/>',
  chat:'<path d="M20 11.5a7.5 7.5 0 0 1-7.5 7.5H5l-3 3V11.5a9 9 0 0 1 18 0Z"/>',
  check:'<path d="m5 12 4 4L19 6"/>',
};
const icon = name => `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${icons[name] || ''}</svg>`;
const brand = `<span class="brand-mark" aria-hidden="true">/›</span>CodeLife<small>®</small>`;
let user = null;
let generation = 0;
let blogCategory = 'all';
let forumCategory = 'all';
let forumQuery = '';
let toastTimer;
let searchGeneration = 0;
let searchTimer;
const topicRequests = new WeakMap();

try { document.body.classList.toggle('dark', localStorage.getItem('codelife-theme') === 'dark'); } catch {}

async function api(path, options = {}) {
  const response = await fetch(path, {credentials:'same-origin', ...options, headers:{...(options.body ? {'Content-Type':'application/json'} : {}), ...options.headers}});
  const data = await response.json().catch(() => ({}));
  if (!response.ok) throw new Error(data.message || data.error || 'Что-то пошло не так. Попробуй ещё раз.');
  return data;
}
const post = (path, data = {}) => api(path, {method:'POST',body:JSON.stringify(data)});
function toast(message) {
  const element = $('#toast');
  element.textContent = message;
  element.classList.add('show');
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => element.classList.remove('show'), 4500);
}
function getRoute() {
  let path = location.pathname.replace(/\/$/, '') || '/';
  const aliases = {'/index.html':'/','/about.html':'/about','/features.html':'/features','/blog.html':'/blog','/contact.html':'/contact','/forum/index.html':'/forum','/user/login.html':'/login','/user/register.html':'/register','/register-user':'/register'};
  return aliases[path] || path.replace(/^\/topic_detail\//, '/forum/');
}
function go(path, replace = false) {
  document.querySelectorAll('dialog[open]').forEach(d => d.close());
  $('#main-nav')?.classList.remove('open');
  $('[data-menu]')?.setAttribute('aria-expanded','false');
  if (location.pathname+location.search+location.hash === path) return;
  history[replace ? 'replaceState' : 'pushState']({}, '', path);
  render();
  $('#main')?.focus({preventScroll:true});
  window.scrollTo({top:0,behavior:'instant'});
}
function active(path, route) {return path === '/' ? route === '/' : route.startsWith(path)||(path==='/blog'&&(route.startsWith('/article/')||route==='/features'));}
function header(route) {
  return `<header class="site-header"><div class="wrap header-inner"><a class="brand" href="/" aria-label="CodeLife — главная">${brand}</a>
    <nav class="nav" id="main-nav" aria-label="Основная навигация">${[['/','Главная'],['/blog','Материалы'],['/forum','Сообщество'],['/about','О проекте']].map(([path,text])=>`<a href="${path}" class="${active(path,route)?'active':''}" ${active(path,route)?'aria-current="page"':''}>${text}</a>`).join('')}</nav>
    <div class="header-actions"><button class="icon-button search-button" data-search aria-label="Поиск по сайту">${icon('search')}<span class="keycap">⌘ K</span></button><button class="icon-button theme-button" data-theme aria-label="Переключить светлую и тёмную тему" aria-pressed="${document.body.classList.contains('dark')}">${icon('moon')}</button>
    ${user?`<button class="button small" data-logout title="Выйти из аккаунта ${escape(user.username)}">${escape(user.username)} <svg class="arrow-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" aria-hidden="true"><path d="M5 19 19 5M5 5h14v14"/></svg></button>`:`<a class="button small" href="/login">Войти <span><svg class="arrow-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" aria-hidden="true"><path d="M5 19 19 5M5 5h14v14"/></svg></span></a>`}
    <button class="icon-button mobile-toggle" data-menu aria-label="Открыть меню" aria-controls="main-nav" aria-expanded="false">${icon('menu')}</button></div></div></header>`;
}
function footer() {
  return `<footer class="footer"><div class="wrap"><div class="footer-top"><a class="brand" href="/">${brand}</a><div class="footer-links"><a href="/blog">Материалы</a><a href="/forum">Форум</a><a href="/contact">Связаться</a><a href="/about">О проекте</a></div><span>СДЕЛАНО РУКАМИ. И ГОЛОВОЙ.</span></div><div class="footer-bottom"><span>© 2026 CodeLife. Кодим, ошибаемся, повторяем.</span><span>Никаких обещаний «в IT за 3 дня». Сорян.</span><span>console.log('ты справишься');</span></div></div></footer>`;
}
const joinBand = () => `<section class="join-band"><div class="wrap join-inner"><div><h2>Один баг — хорошо. Вместе — разберёмся.</h2><p>Задавай вопросы, делись находками и просто пиши этот чёртов код.</p></div><a class="button" href="${user?'/forum':'/register'}">${user?'Заглянуть на форум':'Залететь в сообщество'} <span><svg class="arrow-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" aria-hidden="true"><path d="M5 19 19 5M5 5h14v14"/></svg></span></a></div></section>`;
function visual(index) {
  return `<div class="article-visual visual-${index%4}" aria-hidden="true">${index===1?'<div class="visual-grid"><i></i><i></i><i></i><i></i><i></i></div>':`<div class="visual-code">${['<em>JS</em><b>PY</b>','{ grid }','git <svg class="arrow-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" aria-hidden="true"><path d="M5 19 19 5M5 5h14v14"/></svg>','await_'][index%4]}</div>`}<span class="visual-label">${['PICK YOUR WEAPON','MAKE IT FIT','COMMIT. REPEAT.','WAIT FOR IT.'][index%4]}</span></div>`;
}
function articleCard(article) {
  const index=articles.indexOf(article);
  return `<a class="article-card" href="/article/${article.slug}">${visual(index)}<div class="article-content"><span class="tag">${escape(article.label)}</span><h3>${escape(article.title)}</h3><p>${escape(article.summary)}</p><div class="article-bottom"><span class="meta">${escape(article.readTime)} на чтение</span><span class="circle-arrow" aria-hidden="true"><svg class="arrow-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" aria-hidden="true"><path d="M5 19 19 5M5 5h14v14"/></svg></span></div></div></a>`;
}
function time(value) {
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) return '';
  return new Intl.DateTimeFormat('ru-RU',{day:'numeric',month:'short',timeZone:'Europe/Moscow'}).format(date);
}
function topicRow(topic,index) {
  return `<a class="topic-row" href="/forum/${topic.id}"><span class="avatar color-${index%3+1}" aria-hidden="true">${escape(topic.username.slice(0,2).toUpperCase())}</span><div class="topic-copy"><h3>${escape(topic.title)}</h3><div class="meta"><span>${escape(labels[topic.category] || topic.category)}</span><span>${escape(topic.username)}</span><span>${time(topic.created_at)}</span></div></div><span class="reply-count" aria-label="${Number(topic.replies)} ответов">${icon('chat')}${Number(topic.replies)}</span></a>`;
}
function home() {
  return `<section class="hero wrap"><div class="hero-top"><span class="eyebrow"><i class="live-dot"></i> НЕЗАВИСИМОЕ СООБЩЕСТВО РАЗРАБОТЧИКОВ</span><span class="eyebrow">EST. 2026 / ALWAYS LEARNING</span></div><div class="hero-grid"><div><h1>МЕНЬШЕ<br>ХЕРНИ.<br><span class="highlight">БОЛЬШЕ КОДА.</span></h1><p class="hero-subtitle">Гайды, разборы и люди, которые тоже гуглят ошибки.<br>Без воды и успешного успеха. Вникай. Пробуй. Делай.</p><div class="hero-buttons"><a class="button lime" href="/blog">Погнали разбираться <span><svg class="arrow-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" aria-hidden="true"><path d="M5 19 19 5M5 5h14v14"/></svg></span></a><a class="button" href="/forum">На форум <span><svg class="arrow-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" aria-hidden="true"><path d="M5 19 19 5M5 5h14v14"/></svg></span></a></div><p class="hero-note">${icon('check')} Для тех, кто начинает. И тех, кто всё ещё учится.</p></div><div class="terminal-art"><span class="art-corner top">// ТВОЙ СЛЕДУЮЩИЙ КОММИТ</span><div class="terminal"><div class="terminal-bar"><i></i><i></i><i></i><span>life.js — CodeLife</span></div><pre class="terminal-code"><span class="comment">// идеального момента не будет</span>
<span class="purple">const</span> developer = <span class="orange">'ты'</span>;

<span class="purple">while</span> (alive) {
  <span class="green">learn</span>();
  <span class="green">build</span>();
  <span class="green">breakThings</span>();
  <span class="green">repeat</span>();
}
<span class="terminal-foot">➜  npm run your-life <b>▌</b></span></pre></div><div class="terminal-sticker">РАБОТАЕТ? НЕ ТРОГАЙ. *</div><span class="art-asterisk" aria-hidden="true">✳</span><span class="art-corner bottom">* ЛАДНО, РАЗБЕРИСЬ.</span></div></div><div class="ticker"><span>В ТВОЁМ СТЕКЕ</span><b>JavaScript</b><span class="asterisk">✳</span><b>Python</b><span class="asterisk">✳</span><b>HTML & CSS</b><span class="asterisk">✳</span><b>Git</b><span class="asterisk">✳</span><b>Здравый смысл</b><span class="asterisk">✳</span></div></section>
  <section class="section wrap"><div class="section-heading"><div><span class="eyebrow">01 / ПОЛЕЗНОЕ ЧТИВО</span><h2>Сначала пойми. Потом пиши.</h2></div><a class="text-link" href="/blog">Все материалы <span><svg class="arrow-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" aria-hidden="true"><path d="M5 19 19 5M5 5h14v14"/></svg></span></a></div><div class="article-grid">${articles.slice(0,3).map(articleCard).join('')}</div></section>
  <section class="section community-section wrap"><div class="two-column"><div><div class="section-heading"><div><span class="eyebrow">02 / ЖИВЫЕ ОБСУЖДЕНИЯ</span><h2>Что за хрень с кодом?</h2></div><a class="text-link" href="/forum">На форум <span><svg class="arrow-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" aria-hidden="true"><path d="M5 19 19 5M5 5h14v14"/></svg></span></a></div><div class="topic-list" id="home-topics"><div class="loading">Загружаем обсуждения…</div></div></div><aside class="manifesto"><span class="eyebrow">КОРОТКО О НАС</span><span class="asterisk" aria-hidden="true">✳</span><h2>Код не обязан<br>быть идеальным.<br><span>Ты тоже.</span></h2><p>Мы не гуру и не продаём волшебный вход в IT. Просто делимся тем, что сами поняли. Иногда материмся. Всегда по делу.</p><a class="text-link" href="/about">Узнать, что мы за люди <span><svg class="arrow-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" aria-hidden="true"><path d="M5 19 19 5M5 5h14v14"/></svg></span></a></aside></div></section>
  <section class="section tracks-section wrap"><div class="section-heading"><div><span class="eyebrow">03 / С ЧЕГО НАЧАТЬ</span><h2>Хватит метаться. Вот маршрут.</h2></div><a class="text-link" href="/features">Все маршруты <span><svg class="arrow-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" aria-hidden="true"><path d="M5 19 19 5M5 5h14v14"/></svg></span></a></div><div class="track-grid">${tracks.map((track,i)=>`<article class="track-card"><span class="track-number">/ 0${i+1} — ${i===0?'HTML → CSS → JS':i===1?'PRINT → BUILD → REPEAT':'GIT → CLI → DEBUG'}</span><h3>${escape(track.title)}</h3><p>${escape(track.summary)}</p><a class="text-link" href="/features#${track.id}">Открыть маршрут <span><svg class="arrow-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" aria-hidden="true"><path d="M5 19 19 5M5 5h14v14"/></svg></span></a></article>`).join('')}</div></section>${joinBand()}`;
}
function pageHead(eyebrow,title,description='',extra='') {
  return `<div class="wrap page-head"><div class="breadcrumbs"><a href="/">Главная</a><span>/</span><span>${escape(eyebrow)}</span></div><span class="eyebrow">${escape(eyebrow)}</span><h1>${title}</h1>${description?`<p>${description}</p>`:''}${extra}</div>`;
}
function categoryButtons(current) {
  return [['all','Всё подряд'],...Object.entries(labels)].map(([id,text])=>`<button class="chip ${id===current?'selected':''}" data-category="${id}" aria-pressed="${id===current}">${text}</button>`).join('');
}
function blog() {
  return `${pageHead('Материалы','Читай. Пробуй.<br>Ломай. <span class="highlight">Разбирайся.</span>','Практические разборы без километровой подводки. Открывай редактор рядом — так полезнее.')}<section class="wrap page-content"><div class="filter-bar" id="blog-filters">${categoryButtons(blogCategory)}<div class="inline-search"><label for="article-search" class="sr-only">Поиск статей</label><input type="search" id="article-search" placeholder="Найти материал…"></div></div><div class="article-grid blog-grid" id="article-list">${articles.filter(a=>blogCategory==='all'||a.category===blogCategory||a.label.toLowerCase().includes(blogCategory)).map(articleCard).join('')}</div></section>${joinBand()}`;
}
function forum() {
  return `${pageHead('Сообщество','Тупых вопросов нет.<br><span class="highlight">Молчать — тупо.</span>','Застрял на ошибке? Нашёл полезную штуку? Делись. Здесь все когда-то забывали точку с запятой.')}<section class="wrap page-content"><div class="forum-layout"><div><div class="filter-bar" id="forum-filters">${categoryButtons(forumCategory)}<div class="inline-search"><label class="sr-only" for="forum-search">Поиск тем</label><input type="search" id="forum-search" placeholder="Найти обсуждение…" value="${escape(forumQuery)}"></div></div><div class="topic-list" id="forum-topics"><div class="loading">Загружаем обсуждения…</div></div><p class="meta" style="line-height:1.8">Первые темы — примеры от CodeLife. Твоя тема появится здесь после отправки.</p></div><aside class="forum-sidebar"><span class="eyebrow">НЕ ЗАСТРЕВАЙ В ОДИНОЧКУ</span><h3 style="margin-top:17px">Давай разбираться.</h3><p>Опиши задачу, покажи ошибку и расскажи, что уже пробовал. Так тебе смогут помочь быстрее.</p><button class="button lime" data-new-topic>Создать тему <span>+</span></button><p>Мат — окей. Травля, спам и чужие личные данные — мимо. Критикуем код, уважаем людей.</p></aside></div></section>`;
}
function about() {
  return `${pageHead('О проекте','Здесь кодят.<br><span class="highlight">И говорят прямо.</span>','CodeLife — место для тех, кому интересна разработка. Неважно, написал ты первый print или уже разбираешь чужой легаси.')}<section class="wrap page-content"><div class="about-banner">Никакой магии. Никакого «войти в IT за выходные».<br>Практика, ошибки и ещё немного практики.</div><div class="values-grid"><article class="value-card"><span class="eyebrow">01 / ПО СУЩЕСТВУ</span><h2>Меньше воды.</h2><p>Каждая статья должна помочь что-то понять или сделать. Если ответ помещается в три строки — не будем растягивать его на три экрана.</p></article><article class="value-card"><span class="eyebrow">02 / БЕЗ ПОНТОВ</span><h2>Не знать — нормально.</h2><p>Опытные тоже гуглят. И тупят. И удаляют рабочий код. Здесь можно задать вопрос, не изображая всезнайку.</p></article><article class="value-card"><span class="eyebrow">03 / С ХАРАКТЕРОМ</span><h2>Мат есть. Травли нет.</h2><p>Наш стиль — намеренно грубый. Но чужое достоинство не баг. Ругаемся на сломанный билд, а не на того, кто просит помощи.</p></article></div><a class="button lime" href="/contact">Есть что сказать? Пиши <span><svg class="arrow-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" aria-hidden="true"><path d="M5 19 19 5M5 5h14v14"/></svg></span></a></section>${joinBand()}`;
}
function features() {
  return `${pageHead('Маршруты','Не знаешь, куда идти?<br><span class="highlight">Начни отсюда.</span>','Три понятных маршрута. Это планы практики, а не платные курсы: открывай шаги и собирай свои проекты.')}<section class="wrap page-content">${tracks.map((track,index)=>`<details class="track-detail" id="${track.id}" ${location.hash==='#'+track.id?'open':''}><summary><div><span class="eyebrow">0${index+1} / ${escape(track.level)} / ${track.lessons.length} ШАГОВ</span><h2>${escape(track.title)}</h2><p>${escape(track.summary)}</p></div></summary><ol class="lesson-list">${track.lessons.map(lesson=>`<li><h3>${escape(lesson.title)}</h3><p>${escape(lesson.description)}</p></li>`).join('')}<li><h3>Застрял? Спроси у сообщества.</h3><p><a class="text-link" href="/forum">Обсудить на форуме <svg class="arrow-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" aria-hidden="true"><path d="M5 19 19 5M5 5h14v14"/></svg></a></p></li></ol></details>`).join('')}</section>${joinBand()}`;
}
function contact() {
  return `${pageHead('Контакты','Есть идея?<br>Нашёл косяк? <span class="highlight">Пиши.</span>','Предложи тему, расскажи об ошибке или просто скажи, что думаешь. Прочитаем без корпоративной херни.')}<section class="wrap page-content contact-layout"><div><div class="contact-note"><h2>Это письмо внутри сайта.</h2><p>Обращение сохранится в базе CodeLife. Отправка на электронную почту пока не подключена — не обещаем ответ и не делаем вид, что он уже летит.</p></div><div class="contact-note"><h2>Сломался код?</h2><p>Лучше <a href="/forum" style="text-decoration:underline">спроси на форуме</a>: там вопрос увидят другие разработчики. Добавь описание ошибки и то, что уже пробовал.</p></div><span class="eyebrow">// КРАТКО, ПОНЯТНО, ПО ДЕЛУ.</span></div><div id="contact-form-container"><form id="contact-form"><label>Как к тебе обращаться<input name="name" autocomplete="name" minlength="2" maxlength="80" required placeholder="Имя или ник"></label><label>Твой email<input type="email" name="email" autocomplete="email" maxlength="254" required placeholder="you@example.com"></label><label>Что случилось?<textarea name="message" rows="6" minlength="10" maxlength="5000" required placeholder="Давай без «здравствуйте, уважаемая администрация»…"></textarea></label><p class="form-error" role="alert"></p><button class="button lime" type="submit">Отправить эту хрень <span><svg class="arrow-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" aria-hidden="true"><path d="M5 19 19 5M5 5h14v14"/></svg></span></button><p class="meta" style="line-height:1.8">Не присылай пароли, токены и чужие личные данные.</p></form></div></section>`;
}
function auth(isRegister) {
  const next=new URLSearchParams(location.search).get('next');
  const nextQuery=next?'?next='+encodeURIComponent(next):'';
  return `<div class="auth-wrap"><section class="auth-card"><span class="eyebrow">// СВОИ ЛЮДИ</span><h1>${isRegister?'Залетай.<br>Будем кодить.':'С возвращением,<br>кодер.'}</h1><p>${isRegister?'Один аккаунт, чтобы спрашивать, отвечать и разбираться вместе. Без обязательного «расскажи о себе».':'Твои баги соскучились. И мы тоже, чёрт возьми.'}</p><form id="auth-form" data-mode="${isRegister?'register':'login'}"><label>Имя пользователя<input name="username" autocomplete="username" required minlength="3" maxlength="24" placeholder="code_crusher">${isRegister?'<span class="hint">3–24 символа: буквы, цифры, дефис, подчёркивание.</span>':''}</label><label>Пароль<input type="password" name="password" autocomplete="${isRegister?'new-password':'current-password'}" required minlength="8" maxlength="128" placeholder="Минимум 8 символов"></label><p class="form-error" role="alert"></p><button class="button lime" type="submit">${isRegister?'Создать аккаунт':'Войти в аккаунт'} <span><svg class="arrow-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" aria-hidden="true"><path d="M5 19 19 5M5 5h14v14"/></svg></span></button></form><p class="auth-foot">${isRegister?`Уже свой? <a href="/login${nextQuery}">Войти</a>`:`Впервые здесь? <a href="/register${nextQuery}">Создай аккаунт</a>`}</p></section><p class="meta" style="text-align:center;margin-top:25px">МАТ РАЗРЕШЁН. ЧУЖИЕ АККАУНТЫ НЕ ТРОГАТЬ.</p></div>`;
}
function articlePage(slug) {
  const article=articles.find(a=>a.slug===slug);
  if(!article)return notFound();
  return `${pageHead('Материалы',escape(article.title),escape(article.summary),`<div class="article-meta"><span class="tag">${escape(article.label)}</span><span class="meta">${escape(article.date)}</span><span class="meta">${escape(article.readTime)} на чтение</span></div>`)}<section class="wrap page-content article-layout"><article class="prose">${article.body}<div style="border-top:1px solid var(--line);padding-top:25px;margin-top:35px"><h2>Разобрался? Проверь на практике.</h2><p>Попробуй пример в своём проекте. Если что-то пошло не так — принеси вопрос на форум.</p><a href="/forum" class="button lime">Обсудить с ребятами <span><svg class="arrow-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" aria-hidden="true"><path d="M5 19 19 5M5 5h14v14"/></svg></span></a></div></article><aside class="article-aside"><span class="eyebrow">ЕЩЁ ПО ТЕМЕ</span>${articles.filter(a=>a!==article).slice(0,3).map(a=>`<p><a class="text-link" href="/article/${a.slug}">${escape(a.title)} <svg class="arrow-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" aria-hidden="true"><path d="M5 19 19 5M5 5h14v14"/></svg></a></p>`).join('')}<p>Код из статьи можно копировать, ломать и переделывать под свою задачу.</p></aside></section>`;
}
function notFound() {
  return `${pageHead('404','Эта страница<br>куда-то <span class="highlight">съебалась.</span>','Возможно, ссылка сломалась. Главная ещё на месте.')}<div class="wrap page-content"><a class="button lime" href="/">На главную <span><svg class="arrow-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" aria-hidden="true"><path d="M5 19 19 5M5 5h14v14"/></svg></span></a></div>`;
}
function filterArticles() {
  const q=($('#article-search')?.value||'').toLowerCase().trim();
  const filtered=articles.filter(a=>(blogCategory==='all'||a.category===blogCategory||a.label.toLowerCase().includes(blogCategory))&&`${a.title} ${a.summary} ${a.label}`.toLowerCase().includes(q));
  $('#article-list').innerHTML=filtered.length?filtered.map(articleCard).join(''):'<div class="empty-state">Ничего не нашли. Попробуй другую тему или сбрось фильтр.</div>';
}
function errorBlock(error) {return `<div class="error-state">${escape(error.message)}<br><button class="button small" data-retry>Попробовать ещё раз</button></div>`;}
async function loadTopics(containerSelector, limit, currentGeneration=generation) {
  const container=$(containerSelector);
  if(!container)return;
  const requestId=Symbol();
  topicRequests.set(container,requestId);
  const params=new URLSearchParams();
  if(containerSelector==='#forum-topics') {
    if(forumCategory!=='all')params.set('category',forumCategory);
    if(forumQuery)params.set('q',forumQuery);
  }
  const queryAtStart=forumQuery;
  const categoryAtStart=forumCategory;
  try {
    const data=await api('/api/topics?'+params);
    if(currentGeneration!==generation||!container.isConnected||topicRequests.get(container)!==requestId)return;
    if(containerSelector==='#forum-topics'&&(queryAtStart!==forumQuery||categoryAtStart!==forumCategory))return;
    container.innerHTML=data.topics.length?data.topics.slice(0,limit).map(topicRow).join(''):'<div class="empty-state">Пока пусто. Начни обсуждение — не стесняйся.</div>';
  }catch(error){if(currentGeneration===generation&&container.isConnected&&topicRequests.get(container)===requestId)container.innerHTML=errorBlock(error);}
}
async function loadTopic(id,currentGeneration) {
  try {
    const {topic,posts}=await api('/api/topics/'+id);
    if(currentGeneration!==generation)return;
    document.title=topic.title+' — CodeLife';
    $('#main').innerHTML=`${pageHead('Форум',escape(topic.title),'',`<div class="article-meta"><span class="tag">${escape(labels[topic.category])}</span><span class="meta">${posts.length} ответов</span></div>`)}<section class="wrap page-content article-layout"><div><article class="topic-panel"><div class="post-heading"><span class="avatar color-2">${escape(topic.username.slice(0,2).toUpperCase())}</span><strong>${escape(topic.username)}</strong><span class="meta">${time(topic.created_at)}</span></div><div class="post-body">${escape(topic.content)}</div></article><h2 style="font-size:25px;letter-spacing:-.7px;margin:30px 0 20px">Ответы <span class="meta">/ ${posts.length}</span></h2><div>${posts.length?posts.map(p=>`<article class="topic-panel"><div class="post-heading"><span class="avatar color-1">${escape(p.username.slice(0,2).toUpperCase())}</span><strong>${escape(p.username)}</strong><span class="meta">${time(p.created_at)}</span></div><div class="post-body">${escape(p.content)}</div></article>`).join(''):'<p class="muted">Здесь пока тихо. Будь первым, кто ответит.</p>'}</div>${user?`<form class="reply-form" id="reply-form" data-topic-id="${Number(id)}"><label for="reply-content">Твой ответ</label><textarea id="reply-content" name="content" minlength="2" maxlength="5000" rows="5" required placeholder="Если знаешь — помоги. Если не уверен — так и скажи."></textarea><p class="form-error" role="alert"></p><button class="button lime" type="submit">Отправить ответ <span><svg class="arrow-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" aria-hidden="true"><path d="M5 19 19 5M5 5h14v14"/></svg></span></button></form>`:`<div class="reply-login"><a href="/login?next=${encodeURIComponent('/forum/'+id)}">Войди</a> или <a href="/register?next=${encodeURIComponent('/forum/'+id)}">создай аккаунт</a>, чтобы ответить.</div>`}</div><aside class="article-aside"><a class="text-link" href="/forum">← Все обсуждения</a><p>Помогай разобраться. Критикуй решение, а не человека. Не публикуй чужие пароли и личные данные.</p></aside></section>`;
  }catch(error){if(currentGeneration===generation)$('#main').innerHTML=`<div class="wrap page-content" style="padding-top:50px">${errorBlock(error)}<p><a class="text-link" href="/forum">← К обсуждениям</a></p></div>`;}
}
function render() {
  const route=getRoute();
  const currentGeneration=++generation;
  let content;
  const titles={'/':'Меньше херни, больше кода','/blog':'Материалы','/forum':'Сообщество','/features':'Маршруты','/about':'О проекте','/contact':'Контакты','/login':'Вход','/register':'Регистрация'};
  document.title=(titles[route]||'Разбираемся с кодом')+' — CodeLife';
  if(route==='/')content=home();
  else if(route==='/blog')content=blog();
  else if(route==='/forum')content=forum();
  else if(route==='/about')content=about();
  else if(route==='/features')content=features();
  else if(route==='/contact')content=contact();
  else if(route==='/login'||route==='/register')content=auth(route==='/register');
  else if(route.startsWith('/article/')) {content=articlePage(route.slice(9));const a=articles.find(a=>a.slug===route.slice(9));if(a)document.title=a.title+' — CodeLife';}
  else if(/^\/forum\/\d+$/.test(route))content='<div class="wrap loading">Загружаем обсуждение…</div>';
  else content=notFound();
  $('#app').innerHTML=header(route)+`<main id="main" tabindex="-1">${content}</main>`+footer();
  if(route==='/')loadTopics('#home-topics',3,currentGeneration);
  if(route==='/blog')filterArticles();
  if(route==='/forum')loadTopics('#forum-topics',100,currentGeneration);
  if(/^\/forum\/\d+$/.test(route))loadTopic(route.split('/').at(-1),currentGeneration);
  if(route==='/features'&&location.hash)requestAnimationFrame(()=>document.getElementById(location.hash.slice(1))?.scrollIntoView());
}

function showSearch() {
  $('#search-dialog').showModal();
  $('#global-search').focus();
}
async function searchSite(q) {
  const version=++searchGeneration;
  const container=$('#search-results');
  if(!q){container.innerHTML='<p class="muted">Введи тему — найдём статьи и обсуждения.</p>';return;}
  const articleMatches=articles.filter(a=>`${a.title} ${a.summary} ${a.label}`.toLowerCase().includes(q.toLowerCase()));
  let topicMatches=[];let forumError=false;
  try {topicMatches=(await api('/api/topics?q='+encodeURIComponent(q))).topics.slice(0,5);} catch {forumError=true;}
  if(version!==searchGeneration)return;
  container.innerHTML=articleMatches.map(a=>`<a class="search-result" href="/article/${a.slug}"><span class="eyebrow">СТАТЬЯ / ${escape(a.label)}</span><strong>${escape(a.title)}</strong></a>`).join('')+topicMatches.map(t=>`<a class="search-result" href="/forum/${t.id}"><span class="eyebrow">ОБСУЖДЕНИЕ / ${escape(labels[t.category])}</span><strong>${escape(t.title)}</strong></a>`).join('')+(!articleMatches.length&&!topicMatches.length?'<p class="muted">Ничего не нашли. Попробуй другие слова.</p>':'')+(forumError?'<p class="muted">Поиск по форуму сейчас недоступен. Статьи можно искать.</p>':'');
}
function openNewTopic() {
  if(!user){toast('Чтобы создать тему, сначала войди в аккаунт.');go('/login?next=/forum');return;}
  $('#topic-dialog').showModal();
}
async function submitForm(form,operation) {
  const button=$('button[type="submit"]',form);
  const error=$('.form-error',form);
  button.disabled=true;error.textContent='';
  try {await operation(Object.fromEntries(new FormData(form)));}
  catch(e){error.textContent=e.message;}
  finally{button.disabled=false;}
}
document.addEventListener('click',async event=>{
  const target=event.target.closest('button,a');
  if(!target)return;
  if(target.matches('[data-close]')){target.closest('dialog').close();return;}
  if(target.matches('[data-search]')){showSearch();return;}
  if(target.matches('[data-theme]')) {
    const isDark=document.body.classList.toggle('dark');
    try{localStorage.setItem('codelife-theme',isDark?'dark':'light');}catch{}
    target.setAttribute('aria-pressed',String(isDark));return;
  }
  if(target.matches('[data-menu]')){const expanded=$('#main-nav').classList.toggle('open');target.setAttribute('aria-expanded',String(expanded));return;}
  if(target.matches('[data-logout]')){
    target.disabled=true;
    try{await post('/api/logout');user=null;render();toast('Вышли. Возвращайся, код сам себя не напишет.');}catch(error){target.disabled=false;toast(error.message);}return;
  }
  if(target.matches('[data-new-topic]')){openNewTopic();return;}
  if(target.matches('[data-retry]')){render();return;}
  if(target.matches('[data-category]')) {
    const isBlog=!!target.closest('#blog-filters');
    if(isBlog)blogCategory=target.dataset.category;else forumCategory=target.dataset.category;
    target.parentElement.querySelectorAll('[data-category]').forEach(button=>{const selected=button===target;button.classList.toggle('selected',selected);button.setAttribute('aria-pressed',String(selected));});
    if(isBlog)filterArticles();else loadTopics('#forum-topics',100);
    return;
  }
  if(target.tagName==='A'&&target.origin===location.origin&&!event.metaKey&&!event.ctrlKey&&!event.shiftKey&&!event.altKey&&event.button===0&&!target.download&&target.target!=='_blank'){
    if(target.getAttribute('href')?.startsWith('#'))return;
    event.preventDefault();go(target.pathname+target.search+target.hash);
  }
});
document.addEventListener('input',event=>{
  if(event.target.id==='article-search')filterArticles();
  if(event.target.id==='forum-search') {forumQuery=event.target.value;clearTimeout(event.target.searchTimer);event.target.searchTimer=setTimeout(()=>loadTopics('#forum-topics',100),180);}
  if(event.target.id==='global-search') {clearTimeout(searchTimer);searchGeneration++;const q=event.target.value.trim();searchTimer=setTimeout(()=>searchSite(q),180);}
});
document.addEventListener('keydown',event=>{
  if((event.metaKey||event.ctrlKey)&&event.key.toLowerCase()==='k'){event.preventDefault();if(!$('#search-dialog').open)showSearch();}
});
document.querySelectorAll('dialog').forEach(dialog=>dialog.addEventListener('click',event=>{
  if(event.target!==dialog)return;
  const rect=dialog.getBoundingClientRect();
  if(event.clientX<rect.left||event.clientX>rect.right||event.clientY<rect.top||event.clientY>rect.bottom)dialog.close();
}));
document.addEventListener('submit',event=>{
  const form=event.target;
  if(!['auth-form','topic-form','reply-form','contact-form'].includes(form.id))return;
  event.preventDefault();
  submitForm(form,async data=>{
    if(form.id==='auth-form'){
      const result=await post('/api/'+form.dataset.mode,data);user=result.user;
      const next=new URLSearchParams(location.search).get('next');
      const safeNext=next&&/^\/(forum(?:\/\d+)?|blog|features)$/.test(next)?next:'/forum';
      go(safeNext);toast(form.dataset.mode==='register'?'Ты в деле. Добро пожаловать в CodeLife.':'С возвращением, '+user.username+'.');
    }
    if(form.id==='topic-form'){
      const result=await post('/api/topics',data);$('#topic-dialog').close();form.reset();go('/forum/'+result.topic.id);toast('Тема создана. Теперь разберёмся.');
    }
    if(form.id==='reply-form'){
      await post('/api/topics/'+form.dataset.topicId+'/posts',data);render();toast('Ответ на месте.');
    }
    if(form.id==='contact-form'){
      await post('/api/contact',data);
      $('#contact-form-container').innerHTML='<div class="success-panel" role="status"><h2>Принято, чёрт возьми.</h2><p>Сообщение сохранено в базе сайта. Спасибо, что написал. Электронное письмо не отправлялось.</p><a class="button" href="/blog">Пока можно почитать <span><svg class="arrow-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" aria-hidden="true"><path d="M5 19 19 5M5 5h14v14"/></svg></span></a></div>';
    }
  });
});
window.addEventListener('popstate',()=>{document.querySelectorAll('dialog[open]').forEach(d=>d.close());render();});
try {user=(await api('/api/session')).user;}catch{toast('Не удалось проверить вход. Сервер может быть недоступен.');}
render();
