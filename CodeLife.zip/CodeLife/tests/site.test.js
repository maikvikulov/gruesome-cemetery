import test from 'node:test';
import assert from 'node:assert/strict';
import { mkdtemp, mkdir, writeFile, rm } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { createApp } from '../server/index.js';

const password = 'correct-horse-8451';

async function fixture(t) {
  const dir = await mkdtemp(join(tmpdir(), 'codelife-test-'));
  const clientDir = join(dir, 'client');
  await mkdir(clientDir);
  await writeFile(join(clientDir, 'index.html'), '<!doctype html><title>CodeLife fixture</title>');
  await writeFile(join(clientDir, 'app.js'), 'console.log("fixture");');
  await writeFile(join(dir, 'private.txt'), 'PRIVATE_FILE_NOT_PUBLIC');
  const options = { dbPath: join(dir, 'test.db'), clientDir, seed: false };
  let app;
  let base;
  async function start() {
    app = createApp(options);
    await new Promise((resolve, reject) => {
      app.server.once('error', reject);
      app.server.listen(0, '127.0.0.1', resolve);
    });
    base = `http://127.0.0.1:${app.server.address().port}`;
  }
  await start();
  t.after(async () => {
    await app.close();
    await rm(dir, { recursive: true, force: true });
  });
  return {
    get app() { return app; },
    async restart() {
      await app.close();
      await start();
    },
    async request(path, { method = 'GET', body, cookie } = {}) {
      const headers = {};
      if (body !== undefined) headers['Content-Type'] = 'application/json';
      if (cookie) headers.Cookie = cookie;
      const response = await fetch(base + path, {
        method, headers, body: body === undefined ? undefined : JSON.stringify(body),
      });
      const text = await response.text();
      let data;
      if (response.headers.get('content-type')?.includes('application/json')) data = JSON.parse(text);
      return { status: response.status, headers: response.headers, text, data };
    },
  };
}

async function register(f, username = 'test_coder') {
  const result = await f.request('/api/register', { method: 'POST', body: { username, password } });
  assert.equal(result.status, 201, result.text);
  assert.equal(result.data.user.username, username);
  assert.ok(result.data.user.id);
  const setCookie = result.headers.get('set-cookie');
  assert.ok(setCookie?.includes('HttpOnly'), 'session cookie must be HttpOnly');
  assert.match(setCookie, /SameSite=Lax/i);
  return { user: result.data.user, cookie: setCookie.split(';')[0] };
}

test('account flow creates a real session, rejects duplicate/wrong credentials and invalidates logout', async (t) => {
  const f = await fixture(t);
  const anonymous = await f.request('/api/session');
  assert.equal(anonymous.status, 200);
  assert.equal(anonymous.data.user, null);

  const { user, cookie } = await register(f);
  const signedIn = await f.request('/api/session', { cookie });
  assert.deepEqual(signedIn.data.user, user);
  assert.equal('password' in signedIn.data.user, false);

  const duplicate = await f.request('/api/register', {
    method: 'POST', body: { username: user.username, password },
  });
  assert.equal(duplicate.status, 409);

  const wrong = await f.request('/api/login', {
    method: 'POST', body: { username: user.username, password: 'incorrect-password' },
  });
  assert.equal(wrong.status, 401);

  const logout = await f.request('/api/logout', { method: 'POST', cookie });
  assert.equal(logout.status, 200);
  assert.equal((await f.request('/api/session', { cookie })).data.user, null);

  const login = await f.request('/api/login', {
    method: 'POST', body: { username: user.username, password },
  });
  assert.equal(login.status, 200, login.text);
  const loginCookie = login.headers.get('set-cookie')?.split(';')[0];
  assert.ok(loginCookie);
  assert.deepEqual((await f.request('/api/session', { cookie: loginCookie })).data.user, user);
});

test('forum requires login, saves author and replies, and filters real topics', async (t) => {
  const f = await fixture(t);
  const topicBody = { title: 'Как приручить async await?', content: 'Обсуждаем обработку ошибок и Promise.all. Ошибка 100%: async_await.', category: 'javascript' };
  const unauthorized = await f.request('/api/topics', { method: 'POST', body: topicBody });
  assert.equal(unauthorized.status, 401);

  const { user, cookie } = await register(f);
  const created = await f.request('/api/topics', { method: 'POST', body: topicBody, cookie });
  assert.equal(created.status, 201, created.text);
  const id = created.data.topic.id;
  assert.ok(id);
  assert.equal(created.data.topic.username, user.username);

  const second = await f.request('/api/topics', {
    method: 'POST', cookie,
    body: { title: 'Python: как работают генераторы?', content: 'Разбираемся с yield и ленивыми вычислениями.', category: 'python' },
  });
  assert.equal(second.status, 201, second.text);

  const blockedReply = await f.request(`/api/topics/${id}/posts`, { method: 'POST', body: { content: 'Без логина не публикуется.' } });
  assert.equal(blockedReply.status, 401);
  const reply = await f.request(`/api/topics/${id}/posts`, {
    method: 'POST', cookie, body: { content: 'Используй try/catch и обрабатывай rejected Promise.' },
  });
  assert.equal(reply.status, 201, reply.text);
  assert.equal(reply.data.post.username, user.username);

  const detail = await f.request(`/api/topics/${id}`);
  assert.equal(detail.status, 200, detail.text);
  assert.equal(detail.data.topic.title, topicBody.title);
  assert.equal(detail.data.topic.content, topicBody.content);
  assert.ok(detail.data.posts.some((post) => post.content === reply.data.post.content && post.username === user.username));

  const byCategory = await f.request('/api/topics?category=python');
  assert.equal(byCategory.status, 200);
  assert.equal(byCategory.data.topics.length, 1);
  assert.equal(byCategory.data.topics[0].id, second.data.topic.id);
  const searched = await f.request('/api/topics?q=' + encodeURIComponent('async await'));
  assert.equal(searched.data.topics.length, 1);
  assert.equal(searched.data.topics[0].id, id);
  assert.equal(searched.data.topics[0].replies, 1);
  for (const query of ['КАК ПРИРУЧИТЬ', 'ОБРАБОТКУ ОШИБОК', '%', '_']) {
    const result = await f.request('/api/topics?q=' + encodeURIComponent(query));
    assert.equal(result.status, 200, result.text);
    assert.deepEqual(result.data.topics.map((topic) => topic.id), [id], `search: ${query}`);
  }
});

test('invalid submissions are rejected without creating accounts, topics or replies', async (t) => {
  const f = await fixture(t);
  const weak = await f.request('/api/register', { method: 'POST', body: { username: 'xx', password: '123' } });
  assert.equal(weak.status, 400);
  assert.equal((await f.request('/api/session')).data.user, null);
  const { cookie } = await register(f);
  for (const body of [
    { title: 'x', content: 'Текст достаточно длинный.', category: 'javascript' },
    { title: 'Нормальный заголовок', content: 'Мало', category: 'javascript' },
    { title: 'Нормальный заголовок', content: 'Текст достаточно длинный.', category: 'unknown' },
  ]) {
    const rejected = await f.request('/api/topics', { method: 'POST', cookie, body });
    assert.equal(rejected.status, 400, rejected.text);
  }
  assert.deepEqual((await f.request('/api/topics')).data.topics, []);
  assert.equal((await f.request('/api/topics/999999')).status, 404);
  const noTopic = await f.request('/api/topics/999999/posts', { method: 'POST', cookie, body: { content: 'Ответ в отсутствующую тему.' } });
  assert.equal(noTopic.status, 404);
});

test('contact validates inputs and persists accepted messages', async (t) => {
  const f = await fixture(t);
  const message = { name: 'Тестовый кодер', email: 'coder@example.com', message: 'Хочу предложить тему о CSS Grid и адаптивной вёрстке.' };
  const rejected = await f.request('/api/contact', { method: 'POST', body: { ...message, email: 'broken-address' } });
  assert.equal(rejected.status, 400);
  const accepted = await f.request('/api/contact', { method: 'POST', body: message });
  assert.equal(accepted.status, 201, accepted.text);
  assert.equal(accepted.data.success, true);
  const saved = f.app.db.prepare('SELECT name, email, message FROM contacts').all();
  assert.equal(saved.length, 1);
  assert.deepEqual({ ...saved[0] }, message);
});

test('accounts, sessions and topics survive a server restart', async (t) => {
  const f = await fixture(t);
  const { user, cookie } = await register(f, 'persistent_coder');
  const created = await f.request('/api/topics', {
    method: 'POST', cookie,
    body: { title: 'Тема переживает перезапуск', content: 'Данные сохраняются в SQLite между запусками сервера.', category: 'tools' },
  });
  assert.equal(created.status, 201, created.text);
  await f.restart();
  assert.deepEqual((await f.request('/api/session', { cookie })).data.user, user);
  const detail = await f.request(`/api/topics/${created.data.topic.id}`);
  assert.equal(detail.status, 200);
  assert.equal(detail.data.topic.title, created.data.topic.title);
});

test('static serving supports app routes and never exposes files outside client', async (t) => {
  const f = await fixture(t);
  const home = await f.request('/');
  assert.equal(home.status, 200);
  assert.match(home.text, /CodeLife fixture/);
  assert.match(home.headers.get('content-type'), /text\/html/);
  assert.equal((await f.request('/app.js')).text, 'console.log("fixture");');
  for (const route of ['/forum', '/login', '/register', '/about.html', '/user/login.html', '/forum/index.html']) {
    const result = await f.request(route);
    assert.equal(result.status, 200, route + ': ' + result.text);
    assert.match(result.text, /CodeLife fixture/);
  }
  for (const path of ['/..%2fprivate.txt', '/%2e%2e%2fprivate.txt', '/.git/config', '/server/index.js']) {
    const result = await f.request(path);
    assert.notEqual(result.text, 'PRIVATE_FILE_NOT_PUBLIC', path);
    assert.ok([400, 403, 404].includes(result.status), path + ': ' + result.status);
  }
});
